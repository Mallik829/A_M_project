chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    if (message?.type !== "GET_PAGE_HTML") {
      return;
    }

    getPageHtml(message.url)
      .then(html => {
        sendResponse({
          ok: true,
          html,
          url: message.url
        });
      })
      .catch(error => {
        console.error(
          "Breakdown Exporter:",
          error
        );

        sendResponse({
          ok: false,
          error: error.message
        });
      });

    return true;
  }
);


async function getPageHtml(url) {
  if (
    !url ||
    !url.startsWith(
      "https://talentrep.breakdownexpress.com/"
    )
  ) {
    throw new Error(
      "Invalid Breakdown Express URL."
    );
  }

  const response = await fetch(url, {
    credentials: "include",
    redirect: "follow"
  });

  if (!response.ok) {
    throw new Error(
      `Breakdown Express returned HTTP ${response.status}.`
    );
  }

  const html = await response.text();

  if (!html || html.length < 100) {
    throw new Error(
      "Breakdown Express returned an empty page."
    );
  }

  return html;
}