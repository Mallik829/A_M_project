const scanButton =
  document.getElementById("scan");

const exportButton =
  document.getElementById("export");

const pagesEl =
  document.getElementById("pages");

const countEl =
  document.getElementById("count");

const rolesEl =
  document.getElementById("roles");

const stateEl =
  document.getElementById("state");

const statusEl =
  document.getElementById("status");

const progressInner =
  document.getElementById("progressInner");


let records = [];


scanButton.addEventListener(
  "click",
  startScan
);

exportButton.addEventListener(
  "click",
  exportCSV
);


/* =========================================================
   MAIN SCAN
========================================================= */

async function startScan() {

  scanButton.disabled = true;
  exportButton.disabled = true;

  records = [];

  pagesEl.textContent = "—";
  countEl.textContent = "0";
  rolesEl.textContent = "0";

  setState(
    "Checking Current Breakdowns page…"
  );

  setProgress(0);


  try {

    const tabs =
      await chrome.tabs.query({
        active: true,
        currentWindow: true
      });


    const tab = tabs[0];


    if (!tab || !tab.id) {
      throw new Error(
        "Could not find the active Chrome tab."
      );
    }


    if (
      !tab.url ||
      !tab.url.startsWith(
        "https://talentrep.breakdownexpress.com/"
      )
    ) {
      throw new Error(
        "Open Breakdown Express Current Breakdowns first."
      );
    }


    /*
     * Read the CURRENT page directly.
     */

    const currentHtml =
      await getCurrentTabHTML(
        tab.id
      );


    const pageInfo =
      inspectCurrentListPage(
        currentHtml,
        tab.url
      );


    pagesEl.textContent =
      pageInfo.totalPages;


    setState(
      `Current page found.\n` +
      `Total pages: ${pageInfo.totalPages}\n\n` +
      `Reading list pages…`
    );


    const allRows = [];


    /*
     * Read every list page.
     */

    for (
      let page = 1;
      page <= pageInfo.totalPages;
      page++
    ) {

      setState(
        `Reading list page ${page} of ${pageInfo.totalPages}…`
      );


      let html;


      if (page === pageInfo.currentPage) {

        html = currentHtml;

      } else {

        const url =
          buildPageUrl(
            pageInfo.baseUrl,
            page
          );


        html =
          await fetchPageHTML(
            url
          );
      }


      const result =
        parseListPage(
          html
        );


      for (
        const row of result.rows
      ) {

        row.listPage =
          page;

        allRows.push(row);
      }


      setProgress(
        (page /
          pageInfo.totalPages) *
        30
      );


      await sleep(250);
    }


    /*
     * Deduplicate.
     */

    const unique = [];

    const seen =
      new Set();


    for (
      const row of allRows
    ) {

      if (!row.breakdownId) {
        continue;
      }


      if (
        !seen.has(
          row.breakdownId
        )
      ) {

        seen.add(
          row.breakdownId
        );

        unique.push(row);
      }
    }


    if (!unique.length) {

      throw new Error(
        "No breakdown links were found. " +
        "The Current Breakdowns page structure may be different than expected."
      );
    }


    countEl.textContent =
      unique.length;


    setState(
      `Found ${unique.length} unique breakdowns.\n\n` +
      `Reading individual breakdowns…`
    );


    /*
     * Read every detail page.
     */

    for (
      let i = 0;
      i < unique.length;
      i++
    ) {

      const row =
        unique[i];


      setState(
        `Reading breakdown ${i + 1} of ${unique.length}\n\n` +
        row.title
      );


      let detail;


      try {

        detail =
          await fetchDetailPage(
            row.url
          );

      } catch (error) {

        console.warn(
          "Could not read detail page:",
          row.url,
          error
        );


        /*
         * Keep the breakdown rather than
         * killing the entire scan.
         */

        detail = {
          title: row.title,
          type: row.type || "",
          production: "",
          network: "",
          union: "",
          castingDirector:
            row.castingDirector || "",
          associateCastingDirector: "",
          castingAssistant: "",
          executiveProducers: "",
          director: "",
          writer: "",
          startDate:
            row.startDate || "",
          rate: "",
          location:
            row.location || "",
          deadline: "",
          roles: [],
          sourceUrl: row.url,
          detailError:
            error.message
        };
      }


      row.detail =
        detail;


      row.capturedAt =
        new Date().toISOString();


      records.push(
        row
      );


      countEl.textContent =
        records.length;


      const roleCount =
        records.reduce(
          (sum, item) =>
            sum +
            (
              item.detail?.roles
                ?.length || 0
            ),
          0
        );


      rolesEl.textContent =
        roleCount;


      setProgress(
        30 +
        (
          (i + 1) /
          unique.length
        ) *
        70
      );


      await sleep(250);
    }


    /*
     * Finished.
     */

    const finalRoleCount =
      records.reduce(
        (sum, item) =>
          sum +
          (
            item.detail?.roles
              ?.length || 0
          ),
        0
      );


    stateEl.textContent =
      "Complete";


    setState(
      `Complete.\n\n` +
      `${records.length} breakdowns captured.\n` +
      `${finalRoleCount} roles captured.\n\n` +
      `You can now export the CSV.`
    );


    exportButton.disabled =
      records.length === 0;


  } catch (error) {

    console.error(
      "Breakdown Exporter:",
      error
    );


    stateEl.textContent =
      "Error";


    setState(
      `Scan stopped:\n\n` +
      error.message
    );


  } finally {

    scanButton.disabled =
      false;
  }
}


/* =========================================================
   READ CURRENT TAB
========================================================= */

async function getCurrentTabHTML(
  tabId
) {

  const result =
    await chrome.scripting.executeScript({

      target: {
        tabId: Number(tabId)
      },

      func: () => {

        return document.documentElement
          .outerHTML;
      }

    });


  const html =
    result?.[0]?.result;


  if (
    typeof html !== "string" ||
    html.length < 100
  ) {

    throw new Error(
      "Could not read the Current Breakdowns page."
    );
  }


  return html;
}


/* =========================================================
   INSPECT LIST PAGE
========================================================= */

function inspectCurrentListPage(
  html,
  currentUrl
) {

  const parser =
    new DOMParser();


  const doc =
    parser.parseFromString(
      html,
      "text/html"
    );


  const text =
    cleanMultiline(
      doc.body?.innerText || ""
    );


  /*
   * Try several pagination formats.
   */

  let totalPages = 1;


  const patterns = [

    /Page\s+1\s+of\s+(\d+)/i,

    /Page\s+\d+\s+of\s+(\d+)/i,

    /of\s+(\d+)\s+pages?/i,

    /pages?\s*[:\-]?\s*(\d+)/i

  ];


  for (
    const pattern of patterns
  ) {

    const match =
      text.match(pattern);


    if (match) {

      const number =
        Number(match[1]);


      if (
        Number.isFinite(number) &&
        number > 0
      ) {

        totalPages =
          number;

        break;
      }
    }
  }


  /*
   * Try to determine current page.
   */

  let currentPage = 1;


  const currentMatch =
    text.match(
      /Page\s+(\d+)\s+of\s+(\d+)/i
    );


  if (currentMatch) {

    currentPage =
      Number(
        currentMatch[1]
      );


    totalPages =
      Number(
        currentMatch[2]
      );
  }


  return {

    totalPages,

    currentPage,

    baseUrl:
      currentUrl

  };
}


/* =========================================================
   BUILD PAGE URL
========================================================= */

function buildPageUrl(
  currentUrl,
  page
) {

  const url =
    new URL(
      currentUrl
    );


  url.searchParams.set(
    "page",
    String(page)
  );


  return url.toString();
}


/* =========================================================
   FETCH ANOTHER PAGE
========================================================= */

async function fetchPageHTML(
  url
) {

  const response =
    await chrome.runtime.sendMessage({

      type:
        "GET_PAGE_HTML",

      url

    });


  if (!response?.ok) {

    throw new Error(
      response?.error ||
      "Could not read Breakdown Express page."
    );
  }


  if (
    !response.html ||
    response.html.length < 100
  ) {

    throw new Error(
      "Breakdown Express returned an empty page."
    );
  }


  return response.html;
}


/* =========================================================
   PARSE LIST PAGE
========================================================= */

function parseListPage(
  html
) {

  const parser =
    new DOMParser();


  const doc =
    parser.parseFromString(
      html,
      "text/html"
    );


  const links =
    [
      ...doc.querySelectorAll(
        "a[href]"
      )
    ];


  const rows = [];


  for (
    const link of links
  ) {

    const href =
      link.href;


    if (
      !/view=breakdowns/i.test(
        href
      ) ||
      !/action=details/i.test(
        href
      ) ||
      !/breakdown=\d+/i.test(
        href
      )
    ) {

      continue;
    }


    const title =
      clean(
        link.innerText
      );


    if (!title) {
      continue;
    }


    const tr =
      link.closest("tr");


    let cells = [];


    if (tr) {

      cells =
        [
          ...tr.querySelectorAll(
            "td"
          )
        ].map(td =>
          clean(
            td.innerText
          )
        );
    }


    rows.push({

      breakdownId:
        getBreakdownId(
          href
        ),

      title,

      submitted:
        cells[0] || "",

      type:
        cells[2] || "",

      castingDirector:
        cells[3] || "",

      startDate:
        cells[4] || "",

      location:
        cells[5] || "",

      url:
        href

    });
  }


  return {
    rows
  };
}


/* =========================================================
   DETAIL PAGE
========================================================= */

async function fetchDetailPage(
  url
) {

  const html =
    await fetchPageHTML(
      url
    );


  /*
   * Important diagnostic:
   * don't silently accept a login/empty page.
   */

  if (
    /sign\s*in|log\s*in|login/i.test(
      html
    ) &&
    !/Casting Director|Breakdown|Character/i.test(
      html
    )
  ) {

    throw new Error(
      "Breakdown Express returned a login page instead of the breakdown."
    );
  }


  return parseBreakdownPage(
    html,
    url
  );
}


/* =========================================================
   BREAKDOWN PARSER
========================================================= */

function parseBreakdownPage(
  html,
  url
) {

  const parser =
    new DOMParser();


  const doc =
    parser.parseFromString(
      html,
      "text/html"
    );


  const bodyText =
    cleanMultiline(
      doc.body?.innerText || ""
    );


  if (
    !bodyText
  ) {

    throw new Error(
      "Breakdown page contained no readable text."
    );
  }


  return {

    title:
      getTitle(
        doc,
        bodyText
      ),

    type:
      findType(
        bodyText
      ),

    production:
      findProduction(
        bodyText
      ),

    network:
      findNetwork(
        bodyText
      ),

    union:
      findUnion(
        bodyText
      ),

    castingDirector:
      findLabelValue(
        bodyText,
        "Casting Director"
      ),

    associateCastingDirector:
      findLabelValue(
        bodyText,
        "Associate Casting Director"
      ),

    castingAssistant:
      findLabelValue(
        bodyText,
        "Casting Assistant"
      ),

    executiveProducers:
      findLabelValue(
        bodyText,
        "Executive Producer"
      ),

    director:
      findLabelValue(
        bodyText,
        "Director"
      ),

    writer:
      findLabelValue(
        bodyText,
        "Writer"
      ),

    startDate:
      findLabelValue(
        bodyText,
        "Start Date"
      ),

    rate:
      findLabelValue(
        bodyText,
        "Rate of Pay"
      ),

    location:
      findLabelValue(
        bodyText,
        "Location"
      ),

    deadline:
      findDeadline(
        bodyText
      ),

    roles:
      parseRoles(
        doc,
        bodyText
      ),

    sourceUrl:
      url
  };
}


/* =========================================================
   TITLE
========================================================= */

function getTitle(
  doc,
  bodyText
) {

  const headings =
    [
      ...doc.querySelectorAll(
        "h1, h2, h3, h4"
      )
    ];


  for (
    const el of headings
  ) {

    const text =
      clean(
        el.innerText
      );


    if (
      text &&
      text.length > 5 &&
      !/actors access|resend invitation|email preview/i.test(
        text
      )
    ) {

      return text;
    }
  }


  const lines =
    bodyText
      .split("\n")
      .map(clean)
      .filter(Boolean);


  for (
    const line of lines
  ) {

    if (
      line.length > 8 &&
      /episode|ep\.|film|feature|pilot|series|role|roles/i.test(
        line
      )
    ) {

      return line;
    }
  }


  return "";
}


/* =========================================================
   LABEL VALUE
========================================================= */

function findLabelValue(
  text,
  label
) {

  const lines =
    text
      .split("\n")
      .map(clean)
      .filter(Boolean);


  const index =
    lines.findIndex(
      line =>
        new RegExp(
          `^${escapeRegex(label)}\\s*:?$`,
          "i"
        ).test(line)
    );


  if (
    index >= 0 &&
    lines[index + 1]
  ) {

    return lines[index + 1];
  }


  const regex =
    new RegExp(
      `${escapeRegex(label)}\\s*:?\\s*([^\\n]+)`,
      "i"
    );


  const match =
    text.match(
      regex
    );


  return match
    ? clean(match[1])
    : "";
}


/* =========================================================
   TYPE
========================================================= */

function findType(
  text
) {

  const types = [

    "Episodic",
    "Feature Film",
    "Short",
    "Pilot",
    "Theatre",
    "Stage",
    "Commercial",
    "Print",
    "Internet Project",
    "Web Series",
    "Video Game",
    "Voice Over",
    "Documentary",
    "New Media"

  ];


  for (
    const type of types
  ) {

    if (
      new RegExp(
        `\\b${escapeRegex(type)}\\b`,
        "i"
      ).test(text)
    ) {

      return type;
    }
  }


  return "";
}


/* =========================================================
   PRODUCTION
========================================================= */

function findProduction(
  text
) {

  const match =
    text.match(
      /\b(20th Television|Warner Bros\.?|Universal|Paramount|Sony|Netflix|HBO|Amazon|Apple|Disney|Marvel|Lucasfilm|Lionsgate|MGM|Hulu)\b[^\n]*/i
    );


  return match
    ? clean(match[0])
    : "";
}


/* =========================================================
   NETWORK
========================================================= */

function findNetwork(
  text
) {

  const networks = [

    "HULU",
    "Netflix",
    "HBO Max",
    "HBO",
    "Max",
    "Amazon",
    "Prime Video",
    "Apple TV+",
    "Disney+",
    "Paramount+",
    "Peacock"

  ];


  for (
    const network of networks
  ) {

    if (
      new RegExp(
        `\\b${escapeRegex(network)}\\b`,
        "i"
      ).test(text)
    ) {

      return network;
    }
  }


  return "";
}


/* =========================================================
   UNION
========================================================= */

function findUnion(
  text
) {

  const unions = [

    "SAG-AFTRA",
    "Equity",
    "AEA",
    "Non-Union",
    "AFTRA",
    "DGA",
    "WGA"

  ];


  for (
    const union of unions
  ) {

    if (
      new RegExp(
        `\\b${escapeRegex(union)}\\b`,
        "i"
      ).test(text)
    ) {

      return union;
    }
  }


  return "";
}


/* =========================================================
   DEADLINE
========================================================= */

function findDeadline(
  text
) {

  const match =
    text.match(
      /DEADLINE\s*:?\s*([^\n]+)/i
    );


  return match
    ? clean(match[1])
    : "";
}


/* =========================================================
   ROLES
========================================================= */

function parseRoles(
  doc,
  bodyText
) {

  const roles = [];


  /*
   * First look for bracket format:
   *
   * [DANNY]
   * [WOMAN IN CAR]
   */

  const matches =
    [
      ...bodyText.matchAll(
        /\[([^\]]+)\]\s*([^\n]+(?:\n[^\n]+){0,4})/g
      )
    ];


  for (
    const match of matches
  ) {

    const character =
      clean(
        match[1]
      );


    const description =
      clean(
        match[2]
      );


    if (!character) {
      continue;
    }


    const role =
      parseRoleText(
        `[${character}] ${description}`
      );


    if (
      !roles.some(
        existing =>
          existing.character ===
            role.character &&
          existing.description ===
            role.description
      )
    ) {

      roles.push(
        role
      );
    }
  }


  /*
   * Then inspect tables.
   */

  const tables =
    [
      ...doc.querySelectorAll(
        "table"
      )
    ];


  for (
    const table of tables
  ) {

    const trs =
      [
        ...table.querySelectorAll(
          "tr"
        )
      ];


    for (
      const tr of trs
    ) {

      const cells =
        [
          ...tr.querySelectorAll(
            "th, td"
          )
        ]
          .map(
            td =>
              clean(
                td.innerText
              )
          )
          .filter(Boolean);


      if (!cells.length) {
        continue;
      }


      const joined =
        cells.join(
          " | "
        );


      if (
        !/character|role|portrayed|male|female|man|woman|years old|open ethnicity|guest star|supporting|principal/i.test(
          joined
        )
      ) {

        continue;
      }


      const role =
        parseRoleText(
          joined
        );


      if (
        role.character ||
        role.description
      ) {

        if (
          !roles.some(
            existing =>
              existing.character ===
                role.character &&
              existing.description ===
                role.description
          )
        ) {

          roles.push(
            role
          );
        }
      }
    }
  }


  return roles;
}


/* =========================================================
   ROLE TEXT
========================================================= */

function parseRoleText(
  text
) {

  const characterMatch =
    text.match(
      /^\[([^\]]+)\]/
    );


  const character =
    characterMatch
      ? clean(
          characterMatch[1]
        )
      : "";


  const description =
    clean(
      text.replace(
        /^\[[^\]]+\]\s*/,
        ""
      )
    );


  let age = "";
  let gender = "";
  let ethnicity = "";
  let category = "";
  let scenes = "";
  let days = "";


  const ageMatch =
    description.match(
      /\b(?:male|female|man|woman|boy|girl)?\s*,?\s*(\d{2}s?)\b/i
    );


  if (ageMatch) {
    age =
      ageMatch[1];
  }


  if (
    /\bmale\b|\bman\b/i.test(
      description
    )
  ) {

    gender =
      "Male";

  } else if (
    /\bfemale\b|\bwoman\b/i.test(
      description
    )
  ) {

    gender =
      "Female";
  }


  const ethnicityMatch =
    description.match(
      /(?:open ethnicity|ethnicity[:\s]+)([^.]+)/i
    );


  if (ethnicityMatch) {

    ethnicity =
      clean(
        ethnicityMatch[1]
      );
  }


  const categoryMatch =
    description.match(
      /\b(one scene|two scenes|guest star|co-star|supporting|principal|lead|recurring)\b/i
    );


  if (categoryMatch) {

    category =
      clean(
        categoryMatch[1]
      );
  }


  const scenesMatch =
    description.match(
      /\b(\d+)\s+scenes?\b/i
    );


  if (scenesMatch) {

    scenes =
      scenesMatch[1];
  }


  const daysMatch =
    description.match(
      /\b(\d+)\s+days?\b/i
    );


  if (daysMatch) {

    days =
      daysMatch[1];
  }


  return {

    character,
    age,
    gender,
    ethnicity,
    category,
    scenes,
    days,
    description

  };
}


/* =========================================================
   CSV EXPORT
========================================================= */

function exportCSV() {

  if (!records.length) {
    return;
  }


  const rows = [];


  for (
    const record of records
  ) {

    const detail =
      record.detail || {};


    const roles =
      detail.roles || [];


    if (!roles.length) {

      rows.push(
        makeRow(
          record,
          null
        )
      );

    } else {

      for (
        const role of roles
      ) {

        rows.push(
          makeRow(
            record,
            role
          )
        );
      }
    }
  }


  const columns = [

    "Breakdown ID",
    "Title",
    "Type",
    "Production",
    "Network / Platform",
    "Union",
    "Submitted",
    "Casting Director",
    "Associate Casting Director",
    "Casting Assistant",
    "Executive Producers",
    "Director",
    "Writer",
    "Start Date",
    "Rate of Pay",
    "Location",
    "Deadline",
    "Character",
    "Age",
    "Gender",
    "Ethnicity",
    "Category",
    "Scenes",
    "Days",
    "Role Description",
    "Source Page",
    "Captured At",
    "Source URL"

  ];


  const csv = [

    columns
      .map(csvCell)
      .join(","),

    ...rows.map(
      row =>
        columns
          .map(
            column =>
              csvCell(
                row[column] || ""
              )
          )
          .join(",")
    )

  ].join("\r\n");


  const blob =
    new Blob(
      [
        "\ufeff" +
        csv
      ],
      {
        type:
          "text/csv;charset=utf-8"
      }
    );


  const url =
    URL.createObjectURL(
      blob
    );


  const date =
    new Date()
      .toISOString()
      .slice(
        0,
        10
      );


  chrome.downloads.download({

    url,

    filename:
      `Breakdown-Export-${date}.csv`,

    saveAs:
      true

  });
}


/* =========================================================
   CSV ROW
========================================================= */

function makeRow(
  record,
  role
) {

  const detail =
    record.detail || {};


  return {

    "Breakdown ID":
      record.breakdownId,

    "Title":
      detail.title ||
      record.title,

    "Type":
      detail.type ||
      record.type,

    "Production":
      detail.production || "",

    "Network / Platform":
      detail.network || "",

    "Union":
      detail.union || "",

    "Submitted":
      record.submitted || "",

    "Casting Director":
      detail.castingDirector ||
      record.castingDirector ||
      "",

    "Associate Casting Director":
      detail.associateCastingDirector ||
      "",

    "Casting Assistant":
      detail.castingAssistant ||
      "",

    "Executive Producers":
      detail.executiveProducers ||
      "",

    "Director":
      detail.director ||
      "",

    "Writer":
      detail.writer ||
      "",

    "Start Date":
      detail.startDate ||
      record.startDate ||
      "",

    "Rate of Pay":
      detail.rate ||
      "",

    "Location":
      detail.location ||
      record.location ||
      "",

    "Deadline":
      detail.deadline ||
      "",

    "Character":
      role?.character ||
      "",

    "Age":
      role?.age ||
      "",

    "Gender":
      role?.gender ||
      "",

    "Ethnicity":
      role?.ethnicity ||
      "",

    "Category":
      role?.category ||
      "",

    "Scenes":
      role?.scenes ||
      "",

    "Days":
      role?.days ||
      "",

    "Role Description":
      role?.description ||
      "",

    "Source Page":
      record.listPage ||
      "",

    "Captured At":
      record.capturedAt ||
      "",

    "Source URL":
      record.url ||
      ""

  };
}


/* =========================================================
   UTILITIES
========================================================= */

function csvCell(
  value
) {

  return `"${String(value)
    .replaceAll(
      '"',
      '""'
    )
    .replace(
      /\r?\n/g,
      " "
    )}"`;
}


function getBreakdownId(
  url
) {

  const match =
    url.match(
      /[?&]breakdown=(\d+)/i
    );


  return match
    ? match[1]
    : "";
}


function clean(
  value
) {

  return String(
    value || ""
  )
    .replace(
      /\u00a0/g,
      " "
    )
    .replace(
      /\s+/g,
      " "
    )
    .trim();
}


function cleanMultiline(
  value
) {

  return String(
    value || ""
  )
    .replace(
      /\u00a0/g,
      " "
    )
    .split("\n")
    .map(
      line =>
        line
          .replace(
            /\s+/g,
            " "
          )
          .trim()
    )
    .filter(Boolean)
    .join("\n");
}


function escapeRegex(
  value
) {

  return String(
    value
  ).replace(
    /[.*+?^${}()|[\]\\]/g,
    "\\$&"
  );
}


function sleep(
  ms
) {

  return new Promise(
    resolve =>
      setTimeout(
        resolve,
        ms
      )
  );
}


function setState(
  text
) {

  statusEl.textContent =
    text;
}


function setProgress(
  percent
) {

  progressInner.style.width =
    `${Math.min(
      100,
      Math.max(
        0,
        percent
      )
    )}%`;
}